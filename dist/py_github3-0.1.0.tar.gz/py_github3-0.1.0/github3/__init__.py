"Github API v3 library for Python"
VERSION = (0, 1, 0)

__author__ = "Dev Jones"
__contact__ = "devjones100@gmail.com"
__homepage__ = "http://github.com/devjones/py_github3"
__version__ = ".".join(map(str, VERSION))
__doc__ = "Write to github"
