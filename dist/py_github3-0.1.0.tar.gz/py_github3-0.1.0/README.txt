===============
PyGithub3
===============



This is ultimately intended to be a python library for the Github v3 API.


Currently, the library only implements commits to Github from local files.

However, as time permits I may implement a complete implementation of the new Github v3 API for python as there doesn't seem to be one available.


A Section
===============
